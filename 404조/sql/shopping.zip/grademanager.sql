create table grademanager(

id  varchar(100),
changegrade varchar(100),
basegrade varchar(100),
reason varchar(100),	 		
onstop varchar(100),	
outstop	varchar(100),
type varchar(100)
);

desc grademanager
select * from grademanager
drop table grademanager